<?php $__env->startComponent('mail::message'); ?>
Hello <?php echo e($user->name); ?> 
Thanks for registering in Hot Coffee Mcrosss. 
In this case, you need to verify your email address to login to your account.
<?php $__env->startComponent('mail::button', ['url' => route('verify_email',$user->email_verification_code)]); ?>
Click here to confirm your email
<?php echo $__env->renderComponent(); ?>

<p>Or copy paste the following link on your web browser to verify your email address</p>
<p><a href="<?php echo e(route('verify_email',$user->email_verification_code)); ?>">
    <?php echo e(route('verify_email',$user->email_verification_code)); ?></a></p>

Best Regards,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\project-coffe-hot\resources\views/emails/auth/email_verification_mail.blade.php ENDPATH**/ ?>