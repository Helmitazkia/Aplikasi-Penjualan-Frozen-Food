<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> &#8211; Hot Coffee</title>
    <link rel="stylesheet" type="text/css" href="acount/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="acount/css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="acount/css/iofrm-style.css">
    <link rel="stylesheet" type="text/css" href="acount/css/iofrm-theme19.css">
</head>

<body>
    <div class="form-body without-side">
        <div class="row">
            <div class="img-holder">
                <div class="bg"></div>
                <div class="info-holder">
                    <img src="acount/images/graphic3.svg" alt="">
                </div>
            </div>
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">
                        <h3>Login to account</h3>
                        <p>Access Users Hot Coffe</p>
                        <form>
                            <input class="form-control" type="text" name="username" placeholder="E-mail Address"
                                required>
                            <input class="form-control" type="password" name="password" placeholder="Password" required>
                            <div class="form-button">
                                <button id="submit" type="submit" class="ibtn">Login</button> <a
                                    href="/Forget">Forget password?</a>
                            </div>
                        </form>
                        <div class="other-links">
                            <div class="text">Or login with</div>
                            <a href="#"><i class="fab fa-facebook-f"></i>Facebook</a><a href="#"><i
                                    class="fab fa-google"></i>Google</a><a href="#"><i
                                    class="fab fa-linkedin-in"></i>Linkedin</a>
                        </div>
                        <div class="page-links">
                            <a href="/Registrasi">Register new account</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="acount/js/jquery.min.js"></script>
    <script src="acount/js/popper.min.js"></script>
    <script src="acount/js/bootstrap.min.js"></script>
    <script src="acount/js/main.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\project-coffe-hot\resources\views/v_acount/v_login.blade.php ENDPATH**/ ?>