<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title><?php echo e($title); ?></title>
</head>

<body>
    <!-- MAIN CONTENT -->
    <h1 style="text-align:center">Hello, world</h1>
    <div class="container" style="margin-top:100px;">
        <div class="main">
            <div class="main-content project">
                <div class="row">
                    <div class="col-12">
                        <div class="box">
                            <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--enctype="multipart/form-data untuk upload image -->
                            <form action="/Formadd" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="box-body">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12 mb-24"> <label class="form-label">Name
                                                Product</label>
                                            <input type="hidden" name="id" class="form-control"
                                                value="<?php echo e($dataproduct->id); ?>">
                                            <input type="text" name="name" id="disabledTextInput" class="form-control"
                                                value="<?php echo e($dataproduct->name); ?>" placeholder="Coffe Latte *" required>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger mt-2">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-sm-12 mb-24"> <label class="form-label">Price
                                                (IDR)</label>
                                            <input type="number" name="price" id="disabledTextInput"
                                                class="form-control" value="<?php echo e(old('price')); ?>" placeholder="70000 *"
                                                required>
                                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger mt-2">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12 mb-24"> <label
                                                class="form-label">Catagory</label>
                                            <select name="catagory"
                                                class="form-control custom-select select2 select2-hidden-accessible"
                                                data-placeholder="Select Department" tabindex="-1" aria-hidden="true"
                                                data-select2-id="select2-data-22-9i9m">
                                                <option label="Select Catagory" data-select2-id="select2-data-24-ktnv"
                                                    value="<?php echo e(old('catagory')); ?>">>
                                                </option>
                                                <option>Desserts</option>
                                                <option>Drinks</option>
                                                <option>Events</option>
                                                <option>Recipes</option>
                                                <option>Restauranst</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 col-sm-12 mb-24"> <label class="form-label">Image</label>
                                            <input type="file" name="image" id="disabledTextInput" class="form-control"
                                                value="<?php echo e(old('image')); ?>" placeholder="Latte Hot *" required>
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger mt-2">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group mb-24"> <label class="form-label">Description
                                            Product:</label>
                                        <textarea class="form-control" name="desc" cols="30" rows="10"
                                            value="<?php echo e(old('desc')); ?>" value="<?php echo e(old('desc')); ?>" required></textarea>
                                        <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mt-2">
                                            <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="gr-btn mt-15">
                                    <a href="Dashboardshow" class="btn btn-danger">Close</a>
                                    <button type="submit" class="btn btn-primary">Add Product</button>
                                </div>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>



</body>

</html>
<?php /**PATH C:\xampp\htdocs\project-coffe-hot\resources\views/v_admin/product/v_update.blade.php ENDPATH**/ ?>