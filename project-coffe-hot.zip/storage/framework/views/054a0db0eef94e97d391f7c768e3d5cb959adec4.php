
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en-US" class="scheme_original">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="7tnFD0yri3r6aRw0fPUNXMTMFu9GV-9RIMSQ5GPNvFM" />
    <link rel="icon" type="image/x-icon" href="images/favicon.png" />
    <title>Hot Coffee &#8211; <?php echo e($title); ?></title>
    <link rel='stylesheet'
        href="https://fonts.googleapis.com/css?family=Droid+Serif:400,400i,700,700i|Grand+Hotel|Open+Sans:300,400,600,700,800|Raleway:100,200,300,400,500,600,700,800,900|Source+Sans+Pro:300,300i,400,400i,600,600i,700,700i|Ubuntu:300,300i,400,400i,500,500i,700,700i&amp;subset=latin-ext"
        type='text/css' media='all'>
    <link rel='stylesheet' href='js/vendor/revslider/settings.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/woo/woocommerce-layout.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/woo/woocommerce-smallscreen.css' type='text/css'
        media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' href='js/vendor/woo/woocommerce.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/fontello/css/fontello.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/core.animation.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/shortcodes.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/woo/plugin.woocommerce.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/skin.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/doc-style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/responsive.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/skin.responsive.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/comp/comp.min.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/custom.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/core.messages.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/core.portfolio.css' type='text/css' media='all' />
</head>

<body
    class="home page body_filled article_style_stretch scheme_original top_panel_show top_panel_above sidebar_hide sidebar_outer_hide preloader vc_responsive">
    <div id="page_preloader"></div>
    <a id="toc_home" class="sc_anchor" title="Home"
        data-description="&lt;i&gt;Return to Home&lt;/i&gt; - &lt;br&gt;navigate to home page of the site"
        data-icon="icon-home" data-url="index.html" data-separator="yes"></a>
    <a id="toc_top" class="sc_anchor" title="To Top"
        data-description="&lt;i&gt;Back to top&lt;/i&gt; - &lt;br&gt;scroll to top of the page"
        data-icon="icon-double-up" data-url="" data-separator="yes"></a>

    <div class="body_wrap">
        <div class="page_wrap">
            <div class="top_panel_fixed_wrap"></div>

            <!---HEADER START---->
            <header class="top_panel_wrap top_panel_style_3 scheme_original">
                <div class="top_panel_wrap_inner top_panel_inner_style_3 top_panel_position_above">
                    <div class="top_panel_middle">
                        <div class="content_wrap">
                            <div class="contact_logo">
                                <div class="logo">
                                    <a href="index.html">
                                        <img src="images/logo.png" class="logo_main" alt="" width="128" height="124">
                                        <img src="images/alternative-logo.png" class="logo_fixed" alt="" width="161"
                                            height="47">
                                    </a>
                                </div>
                            </div>
                            <div class="menu_main_wrap">
                                <a href="#" class="menu_main_responsive_button icon-menu"></a>
                                <nav class="menu_main_nav_area">
                                    <ul id="menu_main" class="menu_main_nav">
                                        <li class="menu-item"><a href="/Home">Home</a></li>
                                        <li class="menu-item"><a href="/Reservation">Reservations</a></li>
                                        <!---<li class="menu-item"><a href="/Menu">Menu</a></li>-->
                                        <li class="menu-item"><a href="/Tentang">Tentang</a>
                                        <li class="menu-item"><a href="/Shop">Menu</a></li>
                                        <li class="menu-item"><a href="/Contacts">Contacts</a></li>
                                        <li
                                            class="menu-item current-menu-ancestor current-menu-parent menu-item-has-children">
                                            <a href="#">Acount</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="/Login">Login</a></li>
                                                <li class="menu-item"><a href="/Registrasi">Registrasi</a></li>
                                                 <li class="menu-item"><a href="/LoginAdmin">LoginAdmin</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </nav>
                                <div class="contact_cart">
                                    <a href="#" class="top_panel_cart_button" data-items="0" data-summa="&#036;0.00">
                                        <span class="contact_icon icon-shopping"></span>
                                        <span class="contact_label contact_cart_label">Your cart:</span>
                                        <span class="contact_cart_totals">
                                            <span class="cart_items">0 Items</span> -
                                            <span class="cart_summa">&#36;0.00</span>
                                        </span>
                                    </a>
                                    <ul class="widget_area sidebar_cart sidebar">
                                        <li>
                                            <div class="widget woocommerce widget_shopping_cart">
                                                <div class="hide_cart_widget_if_empty">
                                                    <div class="widget_shopping_cart_content">
                                                        <ul class="cart_list product_list_widget ">
                                                            <li class="empty">No products in the cart.</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="header_mobile">
                <div class="content_wrap">
                    <div class="menu_button icon-menu"></div>
                    <div class="logo">
                        <a href="index.html">
                            <img src="images/logo.png" class="logo_main" alt="" width="128" height="124">
                        </a>
                    </div>
                    <div class="menu_main_cart top_panel_icon">
                        <a href="#" class="top_panel_cart_button" data-items="0" data-summa="&#036;0.00">
                            <span class="contact_icon icon-shopping"></span>
                            <span class="contact_label contact_cart_label">Your cart:</span>
                            <span class="contact_cart_totals">
                                <span class="cart_items">0 Items</span> -
                                <span class="cart_summa">&#36;0.00</span>
                            </span>
                        </a>
                        <ul class="widget_area sidebar_cart sidebar">
                            <li>
                                <div class="widget woocommerce widget_shopping_cart">
                                    <div class="hide_cart_widget_if_empty">
                                        <div class="widget_shopping_cart_content">
                                            <ul class="cart_list product_list_widget">
                                                <li class="empty">No products in the cart.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="side_wrap">
                    <div class="close">Close</div>
                    <div class="panel_top">
                        <nav class="menu_main_nav_area">
                            <ul id="menu_main" class="menu_main_nav">
                                <li class="menu-item"><a href="/Home">Home</a></li>
                                <li class="menu-item"><a href="/Reservation">Reservations</a></li>
                                <!--<li class="menu-item"><a href="/Menu">Menu</a></li>-->
                                <li class="menu-item"><a href="/Tentang">Tentang</a>
                                <li class="menu-item"><a href="/Shop">Menu</a></li>
                                <li class="menu-item"><a href="/Contacts">Contacts</a></li>
                                 <li class="menu-item menu-item-has-children">
                                    <a href="#">Acount</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item"><a href="/Login">Login</a></li>
                                        <li class="menu-item"><a href="/Registrasi">Registrasi</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="panel_bottom">
                        <div class="contact_socials">
                            <div class="sc_socials sc_socials_type_icons sc_socials_shape_square sc_socials_size_small">
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_twitter">
                                        <span class="icon-twitter"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_facebook">
                                        <span class="icon-facebook"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_gplus">
                                        <span class="icon-gplus"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_linkedin">
                                        <span class="icon-linkedin"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_skype">
                                        <span class="icon-skype"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mask"></div>
            </div>
            <!---HEADER AKHIR---->


            <!---CONTENT START---->
            <section class="slider_wrap slider_fullwide slider_engine_revo slider_alias_main">
                <div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container">
                    <div id="rev_slider_1_1" class="rev_slider fullwidthabanner" data-version="5.1">
                        <ul>
                            <li data-index="rs-3" data-transition="fade" data-slotamount="default" data-easein="default"
                                data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off"
                                data-title="Slide" data-description="">
                                <img src="images/transparent.png" alt="" data-bgposition="center center"
                                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off"
                                    class="rev-slidebg" data-no-retina>
                                <div class="tp-caption Hotcoffee-style-1 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-3-layer-1" data-x="30" data-y="114" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">Segar dan Lezat</div>
                                <div class="tp-caption Hotcoffee-style-2 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-3-layer-2" data-x="41" data-y="335" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">di pagi hari</div>
                                <div class="tp-caption Hotcoffee-style-3 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-3-layer-3" data-x="30" data-y="196" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">kopi</div>
                                <div class="tp-caption Hotcoffee-style-4 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-3-layer-4" data-x="547" data-y="618" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">Dimana bisa kami beli?</div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-2" id="slide-3-layer-5" data-x="742"
                                    data-y="62" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_cup.png" alt="" width="458" height="540" data-ww="458px"
                                        data-hh="540px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-1" id="slide-3-layer-6" data-x="248"
                                    data-y="465" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/slider_1_el_1.png" alt="" width="263" height="174" data-ww="263px"
                                        data-hh="174px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme" id="slide-3-layer-7" data-x="-76" data-y="518"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_5.png" alt="" width="391" height="216"
                                        data-ww="391px" data-hh="216px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-1" id="slide-3-layer-9" data-x="999"
                                    data-y="651" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/slider_1_el_4.png" alt="" width="70" height="134" data-ww="70px"
                                        data-hh="134px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-1" id="slide-3-layer-10"
                                    data-x="545" data-y="244" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_2.png" alt="" width="143" height="86"
                                        data-ww="143px" data-hh="86px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme" id="slide-3-layer-11" data-x="1092" data-y="561"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_3.png" alt="" width="169" height="131"
                                        data-ww="169px" data-hh="131px" data-no-retina>
                                </div>
                            </li>
                            <li data-index="rs-2" data-transition="fade" data-slotamount="default" data-easein="default"
                                data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off"
                                data-title="Slide" data-description="">
                                <img src="images/transparent.png" alt="" data-bgposition="center center"
                                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off"
                                    class="rev-slidebg" data-no-retina>
                                <div class="tp-caption Hotcoffee-style-1 tp-resizeme rs-parallaxlevel-2"
                                    id="slide-2-layer-1" data-x="center" data-hoffset="" data-y="70"
                                    data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">Kami membuat kopi yang enak</div>
                                <div class="tp-caption Hotcoffee-style-5 tp-resizeme rs-parallaxlevel-2"
                                    id="slide-2-layer-3" data-x="center" data-hoffset="" data-y="162"
                                    data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">untuk tamu kami</div>
                                <div class="tp-caption tp-resizeme" id="slide-2-layer-7" data-x="853" data-y="512"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_5.png" alt="" width="391" height="216"
                                        data-ww="391px" data-hh="216px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme" id="slide-2-layer-13" data-x="103" data-y="489"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/slider_1_el_1.png" alt="" width="421" height="301" data-ww="421px"
                                        data-hh="301px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-1" id="slide-2-layer-14"
                                    data-x="443" data-y="244" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/slider_2_el_2.png" alt="" width="560" height="525" data-ww="516px"
                                        data-hh="485px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-1" id="slide-2-layer-12"
                                    data-x="891" data-y="275" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_6.png" alt="" width="72" height="140" data-ww="72px"
                                        data-hh="140px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme" id="slide-2-layer-15" data-x="49" data-y="20"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_3.png" alt="" width="169" height="131"
                                        data-ww="152px" data-hh="118px" data-no-retina>
                                </div>
                            </li>
                            <li data-index="rs-1" data-transition="fade" data-slotamount="default" data-easein="default"
                                data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off"
                                data-title="Slide" data-description="">
                                <img src="images/transparent.png" alt="" data-bgposition="center center"
                                    data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off"
                                    class="rev-slidebg" data-no-retina>
                                <div class="tp-caption Hotcoffee-style-6 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-1-layer-1" data-x="30" data-y="104" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">Kita Tau</div>
                                <div class="tp-caption Hotcoffee-style-6 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-1-layer-2" data-x="41" data-y="330" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">Hidup luar biasa</div>
                                <div class="tp-caption Hotcoffee-style-5 tp-resizeme rs-parallaxlevel-1"
                                    id="slide-1-layer-3" data-x="30" data-y="221" data-width="['auto']"
                                    data-height="['auto']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500" data-splitin="none"
                                    data-splitout="none" data-responsive_offset="on">Bagaimana membuat</div>
                                <div class="tp-caption tp-resizeme" id="slide-1-layer-7" data-x="884" data-y="45"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_5.png" alt="" width="391" height="216"
                                        data-ww="391px" data-hh="216px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme" id="slide-1-layer-11" data-x="-46" data-y="477"
                                    data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_3.png" alt="" width="169" height="131"
                                        data-ww="169px" data-hh="131px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-1" id="slide-1-layer-12"
                                    data-x="441" data-y="442" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;rZ:104;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/main_slider_el_6.png" alt="" width="72" height="140" data-ww="72px"
                                        data-hh="140px" data-no-retina>
                                </div>
                                <div class="tp-caption tp-resizeme rs-parallaxlevel-2" id="slide-1-layer-14"
                                    data-x="570" data-y="328" data-width="['none','none','none','none']"
                                    data-height="['none','none','none','none']" data-transform_idle="o:1;"
                                    data-transform_in="opacity:0;s:300;e:Power2.easeInOut;"
                                    data-transform_out="opacity:0;s:300;s:300;" data-start="500"
                                    data-responsive_offset="on">
                                    <img src="images/slider_1_el_1.png" alt="" width="617" height="439" data-ww="617px"
                                        data-hh="439px" data-no-retina>
                                </div>
                            </li>
                        </ul>
                        <div class="tp-static-layers">
                        </div>
                        <div class="tp-bannertimer"></div>
                    </div>
                </div>
            </section>
            <div class="page_content_wrap page_paddings_yes">
                <div class="content_wrap">
                    <div class="content">
                        <article
                            class="post_item post_item_single post_featured_default post_format_standard page hentry">
                            <section class="post_content">
                                <div data-vc-full-width="true" data-vc-full-width-init="false"
                                    class="vc_row wpb_row vc_row-fluid">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <h2 class="sc_title sc_title_regular sc_align_center margin_top_tiny margin_bottom_small"
                                                    data-animation="animated fadeInUp normal">
                                                    SELAMAT DATANG DI RUMAH KOPI KAMI</h2>
                                                <div class="sc_section margin_bottom_huge aligncenter w80"
                                                    data-animation="animated fadeInUp normal">
                                                    <div class="sc_section_inner">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <p>
                                                                    Dari sudut pandang budaya, kedai kopi sebagian besar
                                                                    berfungsi sebagai pusat interaksi sosial: kedai kopi
                                                                    menyediakan tempat bagi pelanggan untuk berkumpul,
                                                                    berbicara, membaca, menulis, menghibur satu sama
                                                                    lain, atau menghabiskan waktu,baik secara individu
                                                                    maupun dalam kelompok kecil.
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <a href="#"
                                                            class="sc_button sc_button_square sc_button_style_border_1 sc_button_size_large margin_top_medium margin_bottom_small">
                                                            membuat reservasi</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row-full-width"></div>
                                <div data-vc-full-width="true" data-vc-full-width-init="false"
                                    data-vc-stretch-content="true"
                                    class="vc_row wpb_row vc_row-fluid vc_custom_1455542959565 vc_row-no-padding">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="sc_parallax" data-parallax-speed="0.3"
                                                    data-parallax-x-pos="50%" data-parallax-y-pos="50%">
                                                    <div class="sc_parallax_content bg1">
                                                        <div class="sc_parallax_overlay">
                                                            <div
                                                                class="sc_content content_wrap margin_top_huge margin_bottom_null">
                                                                <div
                                                                    class="columns_wrap sc_columns columns_nofluid sc_columns_count_2 margin_bottom_huge">
                                                                    <div class="column-1_2 sc_column_item"></div>
                                                                    <div class="column-1_2 sc_column_item">
                                                                        <div class="sc_section margin_bottom_huge brown"
                                                                            data-animation="animated fadeInUp normal">
                                                                            <div class="sc_section_inner">
                                                                                <h4
                                                                                    class="sc_title sc_title_big margin_top_huge margin_bottom_null">
                                                                                    <br />
                                                                                    Penglaman</h4>
                                                                                <h2
                                                                                    class="sc_title sc_title_style margin_top_null margin_bottom_tiny">
                                                                                    kesenangan manist</h2>
                                                                                <div
                                                                                    class="wpb_text_column wpb_content_element vc_custom_1455040756358">
                                                                                    <div class="wpb_wrapper">
                                                                                        <p>
                                                                                            Kopi diseduh dengan terlebih
                                                                                            dahulu memanggang biji kopi
                                                                                            hijau di atas bara panas di
                                                                                            anglo.
                                                                                            Setelah biji kopi disangrai,
                                                                                            setiap peserta diberi
                                                                                            kesempatan untuk mencicipi
                                                                                            aromatiknya
                                                                                            asap dengan mengembuskannya
                                                                                            ke arah mereka. Ini diikuti
                                                                                            oleh penggilingan.
                                                                                        </p>
                                                                                    </div>
                                                                                </div>
                                                                                <a href="#"
                                                                                    class="sc_button sc_button_square sc_button_style_style sc_button_size_small margin_top_small margin_bottom_small">
                                                                                    Baca lebih lajut&#8230;</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="sc_content content_wrap margin_top_huge margin_bottom_huge">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row-full-width"></div>
                                <div class="vc_row wpb_row vc_row-fluid">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="vc_empty_space space12p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                                <div class="sc_section aligncenter w80"
                                                    data-animation="animated fadeInUp normal">
                                                    <div class="sc_section_inner">
                                                        <h2
                                                            class="sc_title sc_title_regular sc_align_center margin_top_huge margin_bottom_small">
                                                            coffee menu</h2>
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <p>
                                                                    “Saya mencari alam untuk inspirasi saya. Membiarkan
                                                                    hasil alam berbicara.
                                                                    Ada begitu banyak di luar sana, begitu banyak
                                                                    keanggunan dan keindahan.&#8211; Asep Supandi
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <a href="/Shop"
                                                            class="sc_button sc_button_square sc_button_style_border_1 sc_button_size_medium margin_top_medium margin_bottom_large">view
                                                            full menu</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div data-vc-full-width="true" data-vc-full-width-init="false"
                                    class="vc_row wpb_row vc_row-fluid vc_custom_1455545189644">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="vc_empty_space space10p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                                <div id="sc_services_258_wrap" class="sc_services_wrap">
                                                    <div id="sc_services_258"
                                                        class="sc_services sc_services_style_services-3 sc_services_type_icons sc_slider_nopagination sc_slider_nocontrols margin_top_huge margin_bottom_huge"
                                                        data-interval="5914" data-slides-per-view="3"
                                                        data-slides-min-width="250"
                                                        data-animation="animated fadeInUp normal">
                                                        <div class="sc_columns columns_wrap">
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_1" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_1.png"
                                                                            data-title="Corretto">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_1-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Corretto</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_2" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_2.png"
                                                                            data-title="Cioccolato-macchiato">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_2-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Cioccolato-macchiato</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_3" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_3.png"
                                                                            data-title="Espresso">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_3-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Espresso</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_4" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_4.png"
                                                                            data-title="Caramel Macchiatto">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_4-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Caramel Macchiatto</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_5" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_5.png"
                                                                            data-title="Irish Coffee">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_5-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Irish Coffee</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_6" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_6.png"
                                                                            data-title="Americano">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_6-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Americano</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_7" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_7.png"
                                                                            data-title="Doppio">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_7-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Doppio</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_8" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_8.png"
                                                                            data-title="Caffe Latte">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_8-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Caffe Latte</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="column-1_3 column_padding_bottom">
                                                                <div id="sc_services_258_9" class="sc_services_item">
                                                                    <div
                                                                        class="sc_services_item_featured post_featured">
                                                                        <div class="post_thumb"
                                                                            data-image="images/services_9.png"
                                                                            data-title="Cappuccino">
                                                                            <a class="hover_icon hover_icon_link"
                                                                                href="#">
                                                                                <img alt=""
                                                                                    src="images/services_9-300x281.png">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                    <h4 class="sc_services_item_title">
                                                                        <a href="#">Cappuccino</a>
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="vc_empty_space space10p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                                <div class="sc_section margin_top_huge">
                                                    <div class="sc_section_inner"></div>
                                                </div>
                                                <div class="vc_empty_space space10p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                                <div class="sc_section margin_top_huge">
                                                    <div class="sc_section_inner"></div>
                                                </div>
                                                <div class="vc_empty_space space10p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row-full-width"></div>
                                <div data-vc-full-width="true" data-vc-full-width-init="false"
                                    data-vc-stretch-content="true"
                                    class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="wpb_revslider_element wpb_content_element">
                                                    <div id="rev_slider_2_2_wrapper"
                                                        class="rev_slider_wrapper fullwidthbanner-container">
                                                        <div id="rev_slider_2_2" class="rev_slider fullwidthabanner"
                                                            data-version="5.1">
                                                            <ul>
                                                                <li data-index="rs-4" data-transition="fade"
                                                                    data-slotamount="default" data-easein="default"
                                                                    data-easeout="default" data-masterspeed="300"
                                                                    data-thumb="" data-rotate="0"
                                                                    data-saveperformance="off" data-title="Slide"
                                                                    data-description="">
                                                                    <img src="images/transparent.png" alt=""
                                                                        data-bgposition="center center"
                                                                        data-bgfit="cover" data-bgrepeat="no-repeat"
                                                                        class="rev-slidebg" data-no-retina>
                                                                    <div class="tp-caption Hotcoffee-style-7 tp-resizeme"
                                                                        id="slide-4-layer-1" data-x="643" data-y="238"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">Black Tea</div>
                                                                    <div class="tp-caption Hotcoffee-style-8 tp-resizeme"
                                                                        id="slide-4-layer-2" data-x="645" data-y="359"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">
                                                                        CAMPURAN ESPRESSO <br />
                                                                        Panggang Lokal
                                                                    </div>
                                                                    <div class="tp-caption Hotcoffee-style-9 tp-resizeme"
                                                                        id="slide-4-layer-3" data-x="645" data-y="454"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-visibility="['on','on','on','off']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">

                                                                        Nikmati kelezatan pilihan teh hitam kami<br />
                                                                        dan awali hari Anda dengan minuman keras yang
                                                                        memabukkan<br />
                                                                        dan secangkir kenikmatan yang pedas
                                                                    </div>
                                                                    <div class="tp-caption no-style"
                                                                        id="slide-4-layer-4" data-x="654" data-y="565"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none" data-responsive_offset="on"
                                                                        data-responsive="off">
                                                                        <a href="/Shop"
                                                                            class="sc_button sc_button_square sc_button_style_border_2 sc_button_size_medium">view
                                                                            full menu</a>
                                                                    </div>
                                                                    <div class="tp-caption tp-resizeme"
                                                                        id="slide-4-layer-5" data-x="70" data-y="205"
                                                                        data-width="['none','none','none','none']"
                                                                        data-height="['none','none','none','none']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="x:-50px;opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="x:-50px;opacity:0;s:500;s:500;"
                                                                        data-start="500" data-responsive_offset="on">
                                                                        <img src="images/main_cup.png" alt=""
                                                                            width="524" height="523" data-ww="524px"
                                                                            data-hh="523px" data-no-retina>
                                                                    </div>
                                                                    <div class="tp-caption tp-resizeme"
                                                                        id="slide-4-layer-6" data-x="649" data-y="118"
                                                                        data-width="['none','none','none','none']"
                                                                        data-height="['none','none','none','none']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-responsive_offset="on">
                                                                        <img src="images/second_slider_el_2.png" alt=""
                                                                            width="202" height="104" data-ww="202px"
                                                                            data-hh="104px" data-no-retina>
                                                                    </div>
                                                                </li>
                                                                <li data-index="rs-5" data-transition="fade"
                                                                    data-slotamount="default" data-easein="default"
                                                                    data-easeout="default" data-masterspeed="300"
                                                                    data-thumb="" data-rotate="0"
                                                                    data-saveperformance="off" data-title="Slide"
                                                                    data-description="">
                                                                    <img src="images/transparent.png" alt=""
                                                                        data-bgposition="center center"
                                                                        data-bgfit="cover" data-bgrepeat="no-repeat"
                                                                        class="rev-slidebg" data-no-retina>
                                                                    <div class="tp-caption Hotcoffee-style-7 tp-resizeme"
                                                                        id="slide-5-layer-1" data-x="643" data-y="238"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">Iced Coffee</div>
                                                                    <div class="tp-caption Hotcoffee-style-8 tp-resizeme"
                                                                        id="slide-5-layer-2" data-x="645" data-y="359"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">
                                                                        ESPRESSO BLEND <br />
                                                                        Locally Roasted
                                                                    </div>
                                                                    <div class="tp-caption Hotcoffee-style-9 tp-resizeme"
                                                                        id="slide-5-layer-3" data-x="645" data-y="454"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-visibility="['on','on','on','off']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">
                                                                        Delicate crispy taste of the finest coffee
                                                                        grains is <br />
                                                                        combined with fresh creamy milk, poured right on
                                                                        <br />
                                                                        cooling ice for serving
                                                                    </div>
                                                                    <div class="tp-caption no-style"
                                                                        id="slide-5-layer-4" data-x="654" data-y="565"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none" data-responsive_offset="on"
                                                                        data-responsive="off">
                                                                        <a href="/Shop"
                                                                            class="sc_button sc_button_square sc_button_style_border_2 sc_button_size_medium">view
                                                                            full menu</a>
                                                                    </div>
                                                                    <div class="tp-caption tp-resizeme"
                                                                        id="slide-5-layer-6" data-x="649" data-y="118"
                                                                        data-width="['none','none','none','none']"
                                                                        data-height="['none','none','none','none']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-responsive_offset="on">
                                                                        <img src="images/second_slider_el_2.png" alt=""
                                                                            width="202" height="104" data-ww="202px"
                                                                            data-hh="104px" data-no-retina>
                                                                    </div>
                                                                    <div class="tp-caption tp-resizeme"
                                                                        id="slide-5-layer-7" data-x="49" data-y="62"
                                                                        data-width="['none','none','none','none']"
                                                                        data-height="['none','none','none','none']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="x:-50px;opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="x:-50px;opacity:0;s:500;s:500;"
                                                                        data-start="500" data-responsive_offset="on">
                                                                        <img src="images/main_cup.png" alt=""
                                                                            width="571" height="699" data-ww="571px"
                                                                            data-hh="699px" data-no-retina>
                                                                    </div>
                                                                </li>
                                                                <li data-index="rs-6" data-transition="fade"
                                                                    data-slotamount="default" data-easein="default"
                                                                    data-easeout="default" data-masterspeed="300"
                                                                    data-thumb="" data-rotate="0"
                                                                    data-saveperformance="off" data-title="Slide"
                                                                    data-description="">
                                                                    <img src="images/transparent.png" alt=""
                                                                        data-bgposition="center center"
                                                                        data-bgfit="cover" data-bgrepeat="no-repeat"
                                                                        class="rev-slidebg" data-no-retina>
                                                                    <div class="tp-caption Hotcoffee-style-7 tp-resizeme"
                                                                        id="slide-6-layer-1" data-x="643" data-y="238"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">Espresso</div>
                                                                    <div class="tp-caption Hotcoffee-style-8 tp-resizeme"
                                                                        id="slide-6-layer-2" data-x="645" data-y="359"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">
                                                                        ESPRESSO BLEND <br />
                                                                        Locally Roasted
                                                                    </div>
                                                                    <div class="tp-caption Hotcoffee-style-9 tp-resizeme"
                                                                        id="slide-6-layer-3" data-x="645" data-y="454"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-visibility="['on','on','on','off']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none"
                                                                        data-responsive_offset="on">
                                                                        Every cup is a performance of throroughly
                                                                        pressured hot <br />
                                                                        water through the finest delicious and finely
                                                                        <br />
                                                                        ground compacted coffee
                                                                    </div>
                                                                    <div class="tp-caption no-style"
                                                                        id="slide-6-layer-4" data-x="654" data-y="565"
                                                                        data-width="['auto']" data-height="['auto']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-splitin="none"
                                                                        data-splitout="none" data-responsive_offset="on"
                                                                        data-responsive="off">
                                                                        <a href="/Shop"
                                                                            class="sc_button sc_button_square sc_button_style_border_2 sc_button_size_medium">view
                                                                            full menu</a>
                                                                    </div>
                                                                    <div class="tp-caption tp-resizeme"
                                                                        id="slide-6-layer-6" data-x="649" data-y="118"
                                                                        data-width="['none','none','none','none']"
                                                                        data-height="['none','none','none','none']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="opacity:0;s:500;s:500;"
                                                                        data-start="500" data-responsive_offset="on">
                                                                        <img src="images/second_slider_el_2.png" alt=""
                                                                            width="202" height="104" data-ww="202px"
                                                                            data-hh="104px" data-no-retina>
                                                                    </div>
                                                                    <div class="tp-caption tp-resizeme"
                                                                        id="slide-6-layer-8" data-x="68" data-y="156"
                                                                        data-width="['none','none','none','none']"
                                                                        data-height="['none','none','none','none']"
                                                                        data-transform_idle="o:1;"
                                                                        data-transform_in="x:-50px;opacity:0;s:500;e:Power2.easeInOut;"
                                                                        data-transform_out="x:-50px;opacity:0;s:500;s:500;"
                                                                        data-start="500" data-responsive_offset="on">
                                                                        <img src="images/slider_2_el_2.png" alt=""
                                                                            width="487" height="471" data-ww="487px"
                                                                            data-hh="471px" data-no-retina>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                            <div class="tp-bannertimer tp-bottom"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row-full-width"></div>
                                <div class="vc_row-full-width"></div>
                                <div data-vc-full-width="true" data-vc-full-width-init="false"
                                    class="vc_row wpb_row vc_row-fluid">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="vc_empty_space space10p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                                <h2 class="sc_title sc_title_regular sc_align_center margin_top_huge margin_bottom_large"
                                                    data-animation="animated fadeInUp normal">Artikel yang paling banyak
                                                    dibaca</h2>
                                                <div class="vc_empty_space space10p">
                                                    <span class="vc_empty_space_inner"></span>
                                                </div>
                                                <div id="sc_blogger_282"
                                                    class="sc_blogger layout_short_4 template_portfolio margin_top_tiny margin_bottom_small sc_blogger_horizontal no_description"
                                                    data-animation="animated fadeInUp normal">
                                                    <div class="isotope_wrap" data-columns="4">
                                                        <div
                                                            class="isotope_item isotope_item_short isotope_item_short_4 isotope_column_4">
                                                            <div
                                                                class="post_item post_item_short post_item_short_4 post_format_standard">
                                                                <div class="post_content isotope_item_content">
                                                                    <div class="post_info_wrap info">
                                                                        <div class="info-back">
                                                                            <div class="post_cat">
                                                                                <a href="index.html"
                                                                                    rel="category tag">Cooking</a>
                                                                            </div>
                                                                            <h4 class="post_title">
                                                                                <a href="index.html">Trend Spotting:
                                                                                    French Tart</a>
                                                                            </h4>
                                                                            <div class="post_date">Posted February 15,
                                                                                2016</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="isotope_item isotope_item_short isotope_item_short_4 isotope_column_4">
                                                            <div
                                                                class="post_item post_item_short post_item_short_4 post_format_standard">
                                                                <div class="post_content isotope_item_content">
                                                                    <div class="post_info_wrap info">
                                                                        <div class="info-back">
                                                                            <div class="post_cat">
                                                                                <a href="index.html"
                                                                                    rel="category tag">Cooking</a>
                                                                            </div>
                                                                            <h4 class="post_title">
                                                                                <a href="index.html">Secret of Making
                                                                                    Smoked Pork</a>
                                                                            </h4>
                                                                            <div class="post_date">Posted February 15,
                                                                                2016</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="isotope_item isotope_item_short isotope_item_short_4 isotope_column_4">
                                                            <div
                                                                class="post_item post_item_short post_item_short_4 post_format_standard">
                                                                <div class="post_content isotope_item_content">
                                                                    <div class="post_info_wrap info">
                                                                        <div class="info-back">
                                                                            <div class="post_cat">
                                                                                <a href="#"
                                                                                    rel="category tag">Cooking</a>
                                                                            </div>
                                                                            <h4 class="post_title">
                                                                                <a href="index.html">Life is a
                                                                                    Combination</a>
                                                                            </h4>
                                                                            <div class="post_date">Posted February 15,
                                                                                2016</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="isotope_item isotope_item_short isotope_item_short_4 isotope_column_4">
                                                            <div
                                                                class="post_item post_item_short post_item_short_4 post_format_standard">
                                                                <div class="post_content isotope_item_content">
                                                                    <div class="post_info_wrap info">
                                                                        <div class="info-back">
                                                                            <div class="post_cat">
                                                                                <a href="#"
                                                                                    rel="category tag">Cooking</a>
                                                                            </div>
                                                                            <h4 class="post_title">
                                                                                <a href="index.html">Amazing Dining
                                                                                    Rooms</a>
                                                                            </h4>
                                                                            <div class="post_date">Posted February 15,
                                                                                2016</div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row-full-width"></div>
                            </section>
                        </article>
                        <section class="related_wrap related_wrap_empty"></section>
                    </div>
                    <!---CONTENT AKHIR---->
                </div>
            </div>
        </div>
    </div>



    

<?php echo $__env->make('Layouts/Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-coffe-hot\resources\views/v_shopcoffe/v_home.blade.php ENDPATH**/ ?>