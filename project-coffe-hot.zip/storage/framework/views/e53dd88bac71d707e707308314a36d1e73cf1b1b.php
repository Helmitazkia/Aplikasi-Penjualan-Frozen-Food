
<?php $__env->startSection('contentadmin'); ?>
<div class="main">
    <div class="main-content user">
        <div class="row">
            <div class="col-9 col-xl-12">
                <div class="box card-box mb-20">
                    <div class="icon-box bg-color-1">
                        <div class="icon bg-icon-1">
                            <i class='bx bxs-briefcase'></i>
                        </div>
                        <div class="content">
                            <h5 class="title-box fs-15 mt-2">Total Task</h5>
                            <div class="themesflat-counter fs-14 font-wb color-1">
                                <span class="number" data-from="0" data-to="1225" data-speed="2500"
                                    data-inviewport="yes">1225</span>
                            </div>
                        </div>
                    </div>
                    <div class="icon-box bg-color-2">
                        <div class="icon bg-icon-2">
                            <i class='bx bx-task'></i>
                        </div>
                        <div class="content click-c">
                            <h5 class="title-box fs-15 mt-2">Running Task</h5>
                            <div class="themesflat-counter fs-14 font-wb color-2">
                                <span class="number" data-from="0" data-to="309" data-speed="2500"
                                    data-inviewport="yes">154
                                    +</span>
                            </div>
                        </div>

                    </div>
                    <div class="icon-box bg-color-3">
                        <div class="icon bg-icon-3">
                            <i class='bx bx-block'></i>
                        </div>
                        <div class="content click-c">
                            <h5 class="title-box fs-15 mt-2">On Hold Task</h5>
                            <div class="themesflat-counter fs-14 font-wb color-3">
                                <span class="number" data-from="0" data-to="309" data-speed="2500"
                                    data-inviewport="yes">75
                                    +</span>
                            </div>
                        </div>

                    </div>
                    <div class="icon-box bg-color-5">
                        <div class="icon bg-icon-5">
                            <i class='bx bx-task color-white'></i>
                        </div>
                        <div class="content click-c">
                            <h5 class="title-box fs-15 mt-2">Complete Task</h5>
                            <div class="themesflat-counter fs-14 font-wb color-4">
                                <span class="number" data-from="0" data-to="309" data-speed="2500"
                                    data-inviewport="yes">120
                                    +</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table CONTENT -->
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" class="mr-2">
                    <polyline points="9 11 12 14 22 4"></polyline>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
                <strong>Success ! </strong><?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"
                    stroke-linecap="round" stroke-linejoin="round" class="mr-2">
                    <polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon>
                    <line x1="15" y1="9" x2="9" y2="15"></line>
                    <line x1="9" y1="9" x2="15" y2="15"></line>
                </svg>
                <strong>Error ! </strong><?php echo e(session()->get('error')); ?>

                <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i
                            class="mdi mdi-close"></i></span>
                </button>
            </div>
            <?php endif; ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Data Product</h4>
                    </div>
                    <br>
                    
                    <a href="/Formadd" class="btn btn-primary ml-12" style="width:200px;">Add Product</a>


                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-responsive-md">
                                <thead>
                                    <th>ID</th>
                                    <th>Name Product</th>
                                    <th>Price Product</th>
                                    <th>Description Product</th>
                                    <th>Category</th>
                                    <th>Image</th>
                                    <th>Reaction</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($dataproduct->id); ?></strong></td>
                                        <td>
                                            <?php echo e($dataproduct->name); ?>

                                        </td>
                                        <td><?php echo e($dataproduct->price); ?></td>
                                        <td><?php echo e($dataproduct->description); ?></td>
                                        <td><?php echo e($dataproduct->name_catagory); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/'.$dataproduct->image)); ?>" style="width:100px;">
                                        </td>
                                        <td>
                                            <div class="d-flex">

                                                <button type="button" class="btn btn-primary shadow btn-xs sharp mr-1"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#exampleModal<?php echo e($dataproduct->id); ?>"><i
                                                        class="fa fa-pencil"></i>

                                                </button>
                                                <button type="button" class="btn btn-danger shadow btn-xs sharp hapus"
                                                    data-id="<?php echo e($dataproduct->id); ?>" data-name="<?php echo e($dataproduct->name); ?>"><i
                                                        class="fa fa-trash"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Table-->

            <!-- Modal -->
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Modal -->
            <div class="modal fade" id="exampleModal<?php echo e($dataproduct->id); ?>" tabindex="-1"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="/Updateproduct/<?php echo e($dataproduct->id); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit <?php echo e($dataproduct->name); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" class="form-control" value="<?php echo e($dataproduct->id); ?>"
                                    readonly>
                                <label class="form-label">Name Product</label>
                                <input type="text" name="name" id="disabledTextInput" class="form-control"
                                    value="<?php echo e($dataproduct->name); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <label class="form-label">Price (IDR)</label>
                                <input type="text" name="price" id="disabledTextInput" class="form-control"
                                    value="<?php echo e($dataproduct->price); ?>" required>
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <label class="form-label">Catagory</label>
                                <select name="catagories" class="form-control">
                                    <option>
                                        <?php echo $dataproduct->name_catagory ?>
                                    </option>
                                    <?php $__currentLoopData = $ambilcatagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ambil->id); ?>">
                                        <?php echo $ambil->name_catagory ?>
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <br>
                                <label class="form-label">Description Product:</label>
                                <input type="text" name="desc" id="disabledTextInput" class="form-control"
                                    value="<?php echo e($dataproduct->description); ?>" style="height:80px;" required>
                                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                                <img src="<?php echo e(asset('storage/'.$dataproduct->image)); ?>" style="width:120px;">
                                <br>
                                <br>
                                <label class="form-label">Image</label>
                                <input type="file" name="image" id="disabledTextInput" class="form-control">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-2">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="hidden" name="fotolama" class="form-control"
                                    value="<?php echo e($dataproduct->image); ?>">
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Modal -->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>





<!-- END MAIN CONTENT -->

<?php echo $__env->make('v_layouts_admin/v_header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-coffe-hot\resources\views/v_admin/v_dashboard.blade.php ENDPATH**/ ?>