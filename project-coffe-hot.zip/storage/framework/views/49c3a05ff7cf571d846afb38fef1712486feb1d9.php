
<?php $__env->startSection('contentadmin'); ?>
<?php echo $__env->make('v_layouts_admin/v_header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-coffe-hot\resources\views/v_admin/v_client.blade.php ENDPATH**/ ?>