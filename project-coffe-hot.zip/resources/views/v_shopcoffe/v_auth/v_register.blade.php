@extends('Layouts/Footer')
@section('content')

<!DOCTYPE html>
<html lang="en-US" class="scheme_original">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="google-site-verification" content="7tnFD0yri3r6aRw0fPUNXMTMFu9GV-9RIMSQ5GPNvFM" />
    <link rel="icon" type="image/x-icon" href="images/favicon.png" />
    <title>Hot Coffee &#8211; {{ $title }}</title>
    <link rel='stylesheet'
        href="https://fonts.googleapis.com/css?family=Droid+Serif:400,400i,700,700i|Grand+Hotel|Open+Sans:300,400,600,700,800|Raleway:100,200,300,400,500,600,700,800,900|Source+Sans+Pro:300,300i,400,400i,600,600i,700,700i|Ubuntu:300,300i,400,400i,500,500i,700,700i&amp;subset=latin-ext"
        type='text/css' media='all'>
    <link rel='stylesheet' href='js/vendor/revslider/settings.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/woo/woocommerce-layout.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/woo/woocommerce-smallscreen.css' type='text/css'
        media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' href='js/vendor/woo/woocommerce.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/fontello/css/fontello.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/core.animation.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/shortcodes.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/woo/plugin.woocommerce.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/skin.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/doc-style.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/responsive.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/skin.responsive.css' type='text/css' media='all' />
    <link rel='stylesheet' href='js/vendor/comp/comp.min.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/custom.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/core.messages.css' type='text/css' media='all' />
    <link rel='stylesheet' href='css/core.portfolio.css' type='text/css' media='all' />

</head>

<body
    class="home page body_filled article_style_stretch scheme_original top_panel_show top_panel_above sidebar_hide sidebar_outer_hide preloader vc_responsive">
    <div id="page_preloader"></div>
    <a id="toc_home" class="sc_anchor" title="Home"
        data-description="&lt;i&gt;Return to Home&lt;/i&gt; - &lt;br&gt;navigate to home page of the site"
        data-icon="icon-home" data-url="index.html" data-separator="yes"></a>
    <a id="toc_top" class="sc_anchor" title="To Top"
        data-description="&lt;i&gt;Back to top&lt;/i&gt; - &lt;br&gt;scroll to top of the page"
        data-icon="icon-double-up" data-url="" data-separator="yes"></a>

    <div class="body_wrap">
        <div class="page_wrap">
            <div class="top_panel_fixed_wrap"></div>

            <!---HEADER START---->
            <header class="top_panel_wrap top_panel_style_3 scheme_original">
                <div class="top_panel_wrap_inner top_panel_inner_style_3 top_panel_position_above">
                    <div class="top_panel_middle">
                        <div class="content_wrap">
                            <div class="contact_logo">
                                <div class="logo">
                                    <a href="index.html">
                                        <img src="images/logo.png" class="logo_main" alt="" width="128" height="124">
                                        <img src="images/alternative-logo.png" class="logo_fixed" alt="" width="161"
                                            height="47">
                                    </a>
                                </div>
                            </div>
                            <div class="menu_main_wrap">
                                <a href="#" class="menu_main_responsive_button icon-menu"></a>
                                <nav class="menu_main_nav_area">
                                    <ul id="menu_main" class="menu_main_nav">
                                        <li class="menu-item"><a href="/Home">Home</a></li>
                                        <li class="menu-item"><a href="/Reservation">Reservations</a></li>
                                        <!--<li class="menu-item"><a href="/Menu">Menu</a></li>-->
                                        <li class="menu-item"><a href="/Tentang">Tentang</a>
                                        <li class="menu-item"><a href="/Shop">Menu</a></li>
                                        <li class="menu-item"><a href="/Contacts">Contacts</a></li>
                                        <li
                                            class="menu-item current-menu-ancestor current-menu-parent menu-item-has-children">
                                            <a href="#">Acount</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="/Login">Login</a></li>
                                                <li class="menu-item"><a href="/Registrasi">Registrasi</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </nav>
                                <div class="contact_cart">
                                    <a href="#" class="top_panel_cart_button" data-items="0" data-summa="&#036;0.00">
                                        <span class="contact_icon icon-shopping"></span>
                                        <span class="contact_label contact_cart_label">Your cart:</span>
                                        <span class="contact_cart_totals">
                                            <span class="cart_items">0 Items</span> -
                                            <span class="cart_summa">&#36;0.00</span>
                                        </span>
                                    </a>
                                    <ul class="widget_area sidebar_cart sidebar">
                                        <li>
                                            <div class="widget woocommerce widget_shopping_cart">
                                                <div class="hide_cart_widget_if_empty">
                                                    <div class="widget_shopping_cart_content">
                                                        <ul class="cart_list product_list_widget ">
                                                            <li class="empty">No products in the cart.</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <div class="header_mobile">
                <div class="content_wrap">
                    <div class="menu_button icon-menu"></div>
                    <div class="logo">
                        <a href="index.html">
                            <img src="images/logo.png" class="logo_main" alt="" width="128" height="124">
                        </a>
                    </div>
                    <div class="menu_main_cart top_panel_icon">
                        <a href="#" class="top_panel_cart_button" data-items="0" data-summa="&#036;0.00">
                            <span class="contact_icon icon-shopping"></span>
                            <span class="contact_label contact_cart_label">Your cart:</span>
                            <span class="contact_cart_totals">
                                <span class="cart_items">0 Items</span> -
                                <span class="cart_summa">&#36;0.00</span>
                            </span>
                        </a>
                        <ul class="widget_area sidebar_cart sidebar">
                            <li>
                                <div class="widget woocommerce widget_shopping_cart">
                                    <div class="hide_cart_widget_if_empty">
                                        <div class="widget_shopping_cart_content">
                                            <ul class="cart_list product_list_widget">
                                                <li class="empty">No products in the cart.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="side_wrap">
                    <div class="close">Close</div>
                    <div class="panel_top">
                        <nav class="menu_main_nav_area">
                            <ul id="menu_main" class="menu_main_nav">
                                <li class="menu-item"><a href="/Home">Home</a></li>
                                <li class="menu-item"><a href="/Reservation">Reservations</a></li>
                                <!---<li class="menu-item"><a href="/Menu">Menu</a></li>-->
                                <li class="menu-item"><a href="/Tentang">Tentang</a>
                                <li class="menu-item"><a href="/Shop">Menu</a></li>
                                <li class="menu-item"><a href="/Contacts">Contacts</a></li>
                                <li class="menu-item menu-item-has-children">
                                    <a href="#">Acount</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item"><a href="/Login">Login</a></li>
                                        <li class="menu-item"><a href="/Registrasi">Registrasi</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="panel_bottom">
                        <div class="contact_socials">
                            <div class="sc_socials sc_socials_type_icons sc_socials_shape_square sc_socials_size_small">
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_twitter">
                                        <span class="icon-twitter"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_facebook">
                                        <span class="icon-facebook"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_gplus">
                                        <span class="icon-gplus"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_linkedin">
                                        <span class="icon-linkedin"></span>
                                    </a>
                                </div>
                                <div class="sc_socials_item">
                                    <a href="#" target="_blank" class="social_icons social_skype">
                                        <span class="icon-skype"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mask"></div>
            </div>
            <!---HEADER AKHIR---->


            <div class="top_panel_title top_panel_style_3 title_present breadcrumbs_present scheme_original">
                <div
                    class="top_panel_title_inner top_panel_inner_style_3 title_present_inner breadcrumbs_present_inner breadcrumbs_1">
                    <div class="content_wrap">
                        <h1 class="page_title">Registration</h1>
                        <div class="breadcrumbs">
                            <a class="breadcrumbs_item home" href="/Home">Home</a>
                            <span class="breadcrumbs_delimiter"></span>
                            <span class="breadcrumbs_item current">Registration</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page_content_wrap page_paddings_yes">
                <div class="content_wrap">
                    <div class="content">
                        <article
                            class="post_item post_item_single post_featured_default post_format_standard page hentry">
                            <section class="post_content">
                                <div class="vc_row wpb_row vc_row-fluid vc_custom_1455186654343">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <h2
                                                    class="sc_title sc_title_regular sc_align_center margin_top_null margin_bottom_small">
                                                    BERHUBUNGAN</h2>
                                                <div class="sc_section margin_bottom_large aligncenter">
                                                    <div class="sc_section_inner">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <p>
                                                                    Malam Selasa, setiap Senin, dan Rabu malam, kami
                                                                    menawarkan sebotol sampanye gratis untuk rombongan
                                                                    yang terdiri dari 10 orang atau lebih yang memesan
                                                                    area di bar kami.
                                                                    Jam Buka: 8.00-18.00 Sen-Sab
                                                                    Hubungi tim reservasi kami di (027) 8338 145 untuk
                                                                    informasi lebih lanjut.
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <a href="/Reservation"
                                                            class="sc_button sc_button_square sc_button_style_border_1 sc_button_size_medium margin_top_medium">reservation</a>
                                                    </div>
                                                </div>
                                                <div class="sc_section aligncenter w70">
                                                    <div class="sc_section_inner">
                                                        <div
                                                            class="sc_line sc_line_position_center_center sc_line_style_solid margin_bottom_large">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="vc_row wpb_row vc_row-fluid vc_custom_1455183321063">
                                    <div class="wpb_column vc_column_container vc_col-sm-12">
                                        <div class="vc_column-inner ">
                                            <div class="wpb_wrapper">
                                                <div class="sc_section margin_right_null margin_left_null aligncenter">
                                                    <div class="sc_section_inner">
                                                        <h5 class="sc_title sc_title_regular margin_top_small">
                                                            Registration
                                                        </h5>
                                                        <!---Inputan Register-->
                                                        <div id="sc_form_132_wrap" class="sc_form_wrap">
                                                            <form method="post" action="Registrasipost">
                                                                @csrf
                                                                <div class="sc_form_info">
                                                                    <div class="sc_form_item sc_form_field label_over">
                                                                        <div>
                                                                            <input
                                                                                class="sc_form sc_form_style_form_1 margin_top_small margin_bottom_medium"
                                                                                type="text" name="username" value="{{old('username')}}"
                                                                                placeholder="Username *">
                                                                                <!--Menampilkan Eror-->
                                                                                @error('username')
                                                                                <div class="text-danger mt-2">
                                                                                    {{$message}}
                                                                                </div>
                                                                                @enderror
                                                                        </div>
                                                                        <div>
                                                                            <input
                                                                                class="sc_form sc_form_style_form_1 margin_top_small margin_bottom_medium"
                                                                                type="text" name="email" value="{{old('email')}}"
                                                                                placeholder="E-mail *">
                                                                                  @error('email')
                                                                                <div class="text-danger mt-2">
                                                                                    {{$message}}
                                                                                </div>
                                                                                @enderror
                                                                        </div>
                                                                        <div>
                                                                            <input
                                                                                class="sc_form sc_form_style_form_1 margin_top_small margin_bottom_medium"
                                                                                type="number" name="telepon" value="{{old('telepon')}}"
                                                                                placeholder="Telepon *">
                                                                                  @error('telepon')
                                                                                <div class="text-danger mt-2">
                                                                                    {{$message}}
                                                                                </div>
                                                                                @enderror
                                                                        </div>
                                                                        <div>
                                                                            <input style="height:100px;"
                                                                                class="sc_form sc_form_style_form_1 margin_top_small margin_bottom_medium"
                                                                                type="text" name="alamat" value="{{old('alamat')}}"
                                                                                placeholder="Alamat-Lengkap *">
                                                                                  @error('alamat')
                                                                                <div class="text-danger mt-2">
                                                                                    {{$message}}
                                                                                </div>
                                                                                @enderror
                                                                        </div>
                                                                        <div>
                                                                            <input
                                                                                class="sc_form sc_form_style_form_1 margin_top_small margin_bottom_medium"
                                                                                type="password" name="password" value="{{old('password')}}"
                                                                                placeholder="Password *">
                                                                                  @error('password')
                                                                                <div class="text-danger mt-2">
                                                                                    {{$message}}
                                                                                </div>
                                                                                @enderror
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Registrasi</button>
                                                            </form>
                                                        </div>
                                                        <!---End Inputan Register-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vc_row wpb_row vc_row-fluid">
                                        <div class="wpb_column vc_column_container vc_col-sm-12">
                                            <div class="vc_column-inner ">
                                                <div class="wpb_wrapper">
                                                    <div class="sc_section margin_bottom_huge">
                                                        <div class="sc_section_inner"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </section>
                        </article>
                        <section class="related_wrap related_wrap_empty"></section>
                    </div>
                </div>
            </div>




            }
